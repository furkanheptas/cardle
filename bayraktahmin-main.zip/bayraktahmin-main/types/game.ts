export interface Country {
  name: string;
  flagUrl: string;
  code: string;
}

export interface GameState {
  currentQuestion: number;
  score: number;
  totalQuestions: number;
  selectedCountry: Country | null;
  options: Country[];
  isAnswered: boolean;
  correctAnswer: Country | null;
}
