import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Trophy, Target, Award } from 'lucide-react-native';

export default function StatsScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>İstatistikler</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <View style={styles.iconContainer}>
              <Trophy size={32} color="#f59e0b" />
            </View>
            <Text style={styles.statValue}>0</Text>
            <Text style={styles.statLabel}>Toplam Oyun</Text>
          </View>

          <View style={styles.statCard}>
            <View style={styles.iconContainer}>
              <Target size={32} color="#22c55e" />
            </View>
            <Text style={styles.statValue}>0%</Text>
            <Text style={styles.statLabel}>Başarı Oranı</Text>
          </View>

          <View style={styles.statCard}>
            <View style={styles.iconContainer}>
              <Award size={32} color="#2563eb" />
            </View>
            <Text style={styles.statValue}>0</Text>
            <Text style={styles.statLabel}>En Yüksek Skor</Text>
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>Oyun Hakkında</Text>
          <Text style={styles.infoText}>
            Bayrak Tahmini oyununda dünya ülkelerinin bayraklarını tanımaya çalışın!
            {'\n\n'}
            Her oyunda 10 soru sorulur ve her doğru cevap için 1 puan kazanırsınız.
            {'\n\n'}
            40 farklı ülke bayrağı ile bilginizi test edin!
          </Text>
        </View>

        <View style={styles.tipCard}>
          <Text style={styles.tipTitle}>İpucu</Text>
          <Text style={styles.tipText}>
            Bayrakları daha iyi tanımak için renk kombinasyonlarına ve sembollere dikkat edin!
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1e293b',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 24,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#f8fafc',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
  },
  infoCard: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  infoTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
  },
  infoText: {
    fontSize: 15,
    color: '#475569',
    lineHeight: 24,
  },
  tipCard: {
    backgroundColor: '#dbeafe',
    padding: 20,
    borderRadius: 16,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: '#2563eb',
  },
  tipTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e40af',
    marginBottom: 8,
  },
  tipText: {
    fontSize: 15,
    color: '#1e40af',
    lineHeight: 22,
  },
});
