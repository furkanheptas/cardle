import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Dimensions, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Country } from '@/types/game';
import { generateQuestion } from '@/utils/gameLogic';
import { RotateCcw, ChevronRight } from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function GameScreen() {
  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [score, setScore] = useState(0);
  const [correctAnswer, setCorrectAnswer] = useState<Country | null>(null);
  const [options, setOptions] = useState<Country[]>([]);
  const [selectedOption, setSelectedOption] = useState<Country | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const totalQuestions = 10;

  useEffect(() => {
    loadNewQuestion();
  }, []);

  const loadNewQuestion = () => {
    const { correct, options: newOptions } = generateQuestion();
    setCorrectAnswer(correct);
    setOptions(newOptions);
    setSelectedOption(null);
    setIsAnswered(false);
  };

  const handleAnswer = (selected: Country) => {
    if (isAnswered) return;

    setSelectedOption(selected);
    setIsAnswered(true);

    if (selected.code === correctAnswer?.code) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions) {
      setCurrentQuestion(currentQuestion + 1);
      loadNewQuestion();
    } else {
      handleRestart();
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(1);
    setScore(0);
    loadNewQuestion();
  };

  const getButtonStyle = (option: Country) => {
    if (!isAnswered) return styles.optionButton;

    if (option.code === correctAnswer?.code) {
      return [styles.optionButton, styles.correctButton];
    }

    if (option.code === selectedOption?.code) {
      return [styles.optionButton, styles.wrongButton];
    }

    return [styles.optionButton, styles.disabledButton];
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.scoreContainer}>
          <Text style={styles.scoreText}>Skor: {score}/{totalQuestions}</Text>
          <Text style={styles.questionText}>Soru {currentQuestion}/{totalQuestions}</Text>
        </View>
        <TouchableOpacity onPress={handleRestart} style={styles.restartButton}>
          <RotateCcw size={24} color="#2563eb" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.gameArea} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>Bu bayrak hangi ülkeye ait?</Text>

        {correctAnswer && (
          <View style={styles.flagContainer}>
            <Image
              source={{ uri: correctAnswer.flagUrl }}
              style={styles.flag}
              resizeMode="contain"
            />
          </View>
        )}

        <View style={styles.optionsContainer}>
          {options.map((option) => (
            <TouchableOpacity
              key={option.code}
              style={getButtonStyle(option)}
              onPress={() => handleAnswer(option)}
              disabled={isAnswered}
            >
              <Text style={styles.optionText}>{option.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {isAnswered && (
          <View style={styles.resultContainer}>
            {selectedOption?.code === correctAnswer?.code ? (
              <Text style={styles.correctText}>Doğru!</Text>
            ) : (
              <Text style={styles.wrongText}>
                Yanlış! Doğru cevap: {correctAnswer?.name}
              </Text>
            )}
          </View>
        )}
      </ScrollView>

      <View style={styles.bottomButtonContainer}>
        <TouchableOpacity
          style={[styles.nextButton, !isAnswered && styles.nextButtonDisabled]}
          onPress={handleNext}
          disabled={!isAnswered}
        >
          <Text style={styles.nextButtonText}>
            {currentQuestion < totalQuestions ? 'Sonraki Soru' : 'Yeniden Başla'}
          </Text>
          <ChevronRight size={20} color="#ffffff" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  scoreContainer: {
    flex: 1,
  },
  scoreText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 4,
  },
  questionText: {
    fontSize: 14,
    color: '#64748b',
  },
  restartButton: {
    padding: 8,
  },
  gameArea: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 32,
    paddingBottom: 32,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
    textAlign: 'center',
    marginBottom: 32,
  },
  flagContainer: {
    alignItems: 'center',
    marginBottom: 40,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  flag: {
    width: width - 80,
    height: 200,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    backgroundColor: '#ffffff',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e2e8f0',
  },
  correctButton: {
    backgroundColor: '#dcfce7',
    borderColor: '#22c55e',
  },
  wrongButton: {
    backgroundColor: '#fee2e2',
    borderColor: '#ef4444',
  },
  disabledButton: {
    opacity: 0.5,
  },
  optionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    textAlign: 'center',
  },
  resultContainer: {
    marginTop: 32,
    alignItems: 'center',
    paddingBottom: 20,
  },
  correctText: {
    fontSize: 22,
    fontWeight: '700',
    color: '#22c55e',
  },
  wrongText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#ef4444',
    textAlign: 'center',
  },
  bottomButtonContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 12,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  nextButton: {
    backgroundColor: '#2563eb',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  nextButtonDisabled: {
    backgroundColor: '#cbd5e1',
    opacity: 0.6,
  },
  nextButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
    textAlign: 'center',
  },
});
