import { Country } from '@/types/game';
import { countries } from '@/data/countries';

export function getRandomCountries(count: number): Country[] {
  const shuffled = [...countries].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

export function generateQuestion(): { correct: Country; options: Country[] } {
  const allCountries = getRandomCountries(4);
  const correct = allCountries[0];
  const options = allCountries.sort(() => Math.random() - 0.5);

  return { correct, options };
}
